import gi
import os
import json
import shutil
from pathlib import Path

gi.require_version('Gtk', '4.0')
gi.require_version('Adw', '1')
from gi.repository import Gtk, Adw, Gio, GLib

class DetailPage(Adw.NavigationPage):
    def __init__(self, device_data):
        super().__init__(title=device_data['product'], tag="details")
        
        toolbar_view = Adw.ToolbarView()
        self.set_child(toolbar_view)
        
        header = Adw.HeaderBar()
        toolbar_view.add_top_bar(header)

        scrolled = Gtk.ScrolledWindow(propagate_natural_height=True)
        toolbar_view.set_content(scrolled)

        clamp = Adw.Clamp(maximum_size=450)
        scrolled.set_child(clamp)

        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=24)
        box.set_margin_top(32)
        box.set_margin_bottom(32)
        clamp.set_child(box)

        brand_img = Gtk.Image.new_from_icon_name(device_data['icon'])
        brand_img.set_pixel_size(96)
        brand_img.set_halign(Gtk.Align.CENTER)
        box.append(brand_img)

        labels_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=4)
        box.append(labels_box)

        product_label = Gtk.Label(label=device_data['product'], wrap=True, justify=Gtk.Justification.CENTER)
        product_label.add_css_class("title-1")
        labels_box.append(product_label)

        vendor_label = Gtk.Label(label=device_data['vendor'])
        vendor_label.add_css_class("caption")
        labels_box.append(vendor_label)

        manage_group = Adw.PreferencesGroup(title="Manage this device")
        
        vid_pid_key = f"{device_data['idVendor']}:{device_data['idProduct']}".upper()
        
        has_management = False
        
        polychromatic_data = self.load_json_data("data/devices_polychromatic.json")
        if vid_pid_key in polychromatic_data:
            is_installed = shutil.which("polychromatic") is not None
            
            razer_row = Adw.ActionRow(title="Polychromatic", subtitle="Configure Razer device and RGB")
            razer_row.add_prefix(Gtk.Image.new_from_icon_name("preferences-desktop-keyboard-symbolic"))
            
            if is_installed:
                razer_row.set_activatable(True)
                razer_row.connect("activated", lambda _: self.launch_app("polychromatic"))
                razer_row.add_suffix(Gtk.Image.new_from_icon_name("go-next-symbolic"))
            else:
                install_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=6)
                badge = Gtk.Label(label="Not Installed")
                badge.add_css_class("caption")
                badge.set_opacity(0.6)
                
                install_btn = Gtk.Button(label="Install")
                install_btn.set_sensitive(False)
                install_btn.set_valign(Gtk.Align.CENTER)
                
                install_box.append(badge)
                install_box.append(install_btn)
                razer_row.add_suffix(install_box)
                
            manage_group.add(razer_row)
            has_management = True

        piper_data = self.load_json_data("data/devices_piper.json")
        if vid_pid_key in piper_data:
            is_installed = shutil.which("ratbag-piper") is not None or shutil.which("piper") is not None
            
            mouse_row = Adw.ActionRow(title="Piper", subtitle="Configure mouse settings")
            mouse_row.add_prefix(Gtk.Image.new_from_icon_name("input-mouse-symbolic"))
            
            if is_installed:
                mouse_row.set_activatable(True)
                cmd = "piper" if shutil.which("piper") else "ratbag-piper"
                mouse_row.connect("activated", lambda _: self.launch_app(cmd))
                mouse_row.add_suffix(Gtk.Image.new_from_icon_name("go-next-symbolic"))
            else:
                install_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=6)
                badge = Gtk.Label(label="Not Installed")
                badge.add_css_class("caption")
                badge.set_opacity(0.6)
                
                install_btn = Gtk.Button(label="Install")
                install_btn.set_sensitive(False)
                install_btn.set_valign(Gtk.Align.CENTER)
                
                install_box.append(badge)
                install_box.append(install_btn)
                mouse_row.add_suffix(install_box)
                
            manage_group.add(mouse_row)
            has_management = True
        
        openrgb_data = self.load_json_data("data/devices_openrgb.json")
        if vid_pid_key in openrgb_data:
            is_installed = shutil.which("openrgb") is not None
            
            rgb_row = Adw.ActionRow(title="OpenRGB", subtitle="Adjust device RGB")
            rgb_row.add_prefix(Gtk.Image.new_from_icon_name("display-brightness-symbolic"))
            
            if is_installed:
                rgb_row.set_activatable(True)
                rgb_row.connect("activated", lambda _: self.launch_app("openrgb"))
                rgb_row.add_suffix(Gtk.Image.new_from_icon_name("go-next-symbolic"))
            else:
                install_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=6)
                badge = Gtk.Label(label="Not Installed")
                badge.add_css_class("caption")
                badge.set_opacity(0.6)
                
                install_btn = Gtk.Button(label="Install")
                install_btn.set_sensitive(False)
                install_btn.set_valign(Gtk.Align.CENTER)
                
                install_box.append(badge)
                install_box.append(install_btn)
                rgb_row.add_suffix(install_box)
                
            manage_group.add(rgb_row)
            has_management = True

        if has_management:
            box.append(manage_group)

        info_group = Adw.PreferencesGroup(title="Device Specifications")
        box.append(info_group)

        specs = [
            ("Vendor ID", device_data['idVendor']),
            ("Product ID", device_data['idProduct']),
            ("USB Version", device_data['version']),
            ("Power (Attributes)", device_data['power']),
            ("Manufacturer", device_data['vendor']),
        ]

        for label, value in specs:
            row = Adw.ActionRow(title=label)
            row.add_suffix(Gtk.Label(label=value, selectable=True))
            info_group.add(row)

    def load_json_data(self, file_path):
        try:
            system_path = os.path.join("/usr/share/turbotux/peripheralmanager", file_path)
            if os.path.exists(system_path):
                with open(system_path, 'r') as f:
                    return json.load(f)
            elif os.path.exists(file_path):
                with open(file_path, 'r') as f:
                    return json.load(f)
        except Exception:
            pass
        return {}

    def launch_app(self, command):
        try:
            Gio.AppInfo.create_from_commandline(command, None, Gio.AppInfoCreateFlags.NONE).launch([], None)
        except Exception as e:
            print(f"Failed to launch {command}: {e}")

class PeripheralWindow(Adw.ApplicationWindow):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)

        icon_theme = Gtk.IconTheme.get_for_display(self.get_display())
        system_brands_path = "/usr/share/turbotux/peripheralmanager/brands"
        if os.path.exists(system_brands_path):
            icon_theme.add_search_path(system_brands_path)
        
        brands_path = os.path.abspath("brands")
        if os.path.exists(brands_path):
            icon_theme.add_search_path(brands_path)

        self.set_title("Peripheral Manager")
        self.set_default_size(500, 700)

        self.nav_view = Adw.NavigationView()
        self.set_content(self.nav_view)

        main_page = Adw.NavigationPage(title="Peripherals", tag="main")
        self.nav_view.add(main_page)

        toolbar_view = Adw.ToolbarView()
        main_page.set_child(toolbar_view)
        
        header = Adw.HeaderBar()
        toolbar_view.add_top_bar(header)

        about_btn = Gtk.Button(icon_name="help-about-symbolic")
        about_btn.set_tooltip_text("About")
        about_btn.connect("clicked", self.show_about)
        header.pack_end(about_btn)

        scrolled = Gtk.ScrolledWindow(propagate_natural_height=True)
        toolbar_view.set_content(scrolled)

        clamp = Adw.Clamp(maximum_size=450)
        scrolled.set_child(clamp)

        self.list_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=20)
        self.list_box.set_margin_top(24)
        self.list_box.set_margin_bottom(24)
        clamp.set_child(self.list_box)

        self.devices_group = Adw.PreferencesGroup(title="Connected Hardware")
        self.list_box.append(self.devices_group)

        self.refresh_devices()

    def show_about(self, widget):
        about = Adw.AboutWindow(
            transient_for=self,
            application_name="Peripheral Manager",
            application_icon="input-keyboard",
            developer_name="rubythecutie, techguy16",
            version="0.1.2",
            copyright="© 2026 rubythecutie, techguy16",
            license_type=Gtk.License.GPL_3_0,
            website="https://github.com/turbotuxlinux/peripheralmanager"
        )
        about.present()

    def read_sys_file(self, path):
        try:
            val = Path(path).read_text().strip()
            return val if val else "N/A"
        except: return "N/A"

    def refresh_devices(self):
        base_path = "/sys/bus/usb/devices/"
        seen_devices = set()

        for device_dir in os.listdir(base_path):
            d = os.path.join(base_path, device_dir)
            if os.path.isfile(os.path.join(d, "idVendor")):
                vendor = self.read_sys_file(os.path.join(d, "manufacturer"))
                product = self.read_sys_file(os.path.join(d, "product"))
                
                if product == "N/A" or vendor == "N/A":
                    continue
                
                if not product or "hub" in product.lower() or "xhci" in product.lower():
                    continue
                
                vid = self.read_sys_file(os.path.join(d, "idVendor"))
                pid = self.read_sys_file(os.path.join(d, "idProduct"))
                dev_id = f"{vid}:{pid}"
                
                if dev_id in seen_devices: continue
                seen_devices.add(dev_id)

                brand_name = vendor.split()[0] if vendor and vendor != "N/A" else ""
                
                device_data = {
                    "vendor": vendor,
                    "product": product,
                    "idVendor": vid,
                    "idProduct": pid,
                    "version": self.read_sys_file(os.path.join(d, "version")),
                    "power": self.read_sys_file(os.path.join(d, "bmAttributes")),
                    "icon": brand_name
                }

                row = Adw.ActionRow(title=product, subtitle=vendor)
                row.set_activatable(True)
                row.connect("activated", self.on_row_activated, device_data)
                
                brand_img = Gtk.Image.new_from_icon_name(device_data['icon'])
                brand_img.set_pixel_size(32)
                
                row.add_prefix(brand_img)
                row.add_suffix(Gtk.Image.new_from_icon_name("go-next-symbolic"))
                self.devices_group.add(row)

    def on_row_activated(self, row, device_data):
        detail_page = DetailPage(device_data)
        self.nav_view.push(detail_page)

class MyApp(Adw.Application):
    def __init__(self):
        super().__init__(application_id="io.github.turbotuxlinux.peripheralmanager")

    def do_activate(self):
        win = PeripheralWindow(application=self)
        win.present()

if __name__ == "__main__":
    app = MyApp()
    app.run(None)